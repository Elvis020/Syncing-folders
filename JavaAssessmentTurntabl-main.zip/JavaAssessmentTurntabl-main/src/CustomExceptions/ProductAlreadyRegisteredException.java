package CustomExceptions;

public class ProductAlreadyRegisteredException extends Exception {
    public ProductAlreadyRegisteredException(String message){super(message);}
}
