package Models;

public abstract class Products {
    public String productId;
    public double currentValue;
}
